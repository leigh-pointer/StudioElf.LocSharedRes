/*  
Remove StudioElfLocSharedRes table
*/

DROP TABLE [dbo].[StudioElfLocSharedRes]
GO
