using System.Resources;
using Microsoft.Extensions.Localization;

[assembly: RootNamespace("StudioElf.LocSharedRes.Client")]