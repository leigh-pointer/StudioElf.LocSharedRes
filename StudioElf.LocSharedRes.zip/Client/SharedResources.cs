﻿namespace StudioElf.LocSharedRes.Client
{
    /// <summary>
    /// Dummy class used to collect shared resurce strings for this application
    /// </summary>
    /// <remarks>
    /// This class is mostly used with IStringLocalizer and IHtmlLocalizer interfaces.
    /// </remarks>
    public class SharedResources
    {
    }
}
