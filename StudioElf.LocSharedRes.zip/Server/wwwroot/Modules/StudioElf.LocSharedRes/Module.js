/* Module Script */
var StudioElf = StudioElf || {};

StudioElf.LocSharedRes = {
};